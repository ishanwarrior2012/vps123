/**
 * =============================================================================
 * File: files.ts
 * Project: Parachute
 * Author: g-flame
 * =============================================================================
 *
 * CREDITS:
 * - Parachute addon developed by g-flame
 * - Panel by AirlinkLabs
 *
 * NOTES:
 * - This file is part of the Parachute – Airlink Addons project
 * - All TypeScript logic written by g-flame
 *
 * =============================================================================
 */


import { google } from 'googleapis';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import axios from 'axios';
import * as tar from 'tar';
import archiver from 'archiver';
import { PrismaClient, Logger, BackupResult, RestoreResult, ParachuteBackup, sendProgress, clearProgress } from '../types';
import { getAuthenticatedClient, getDriveFolderId } from './oauth';

/**
 * Check if user has access to server
 */
async function checkServerAccess(
  userId: number | string,
  serverUUID: string,
  prisma: PrismaClient
): Promise<boolean> {
  try {
    const server = await prisma.server.findUnique({
      where: { UUID: serverUUID },
      select: { ownerId: true }
    });

    if (!server) return false;

    const user = await prisma.users.findUnique({
      where: { id: Number(userId) },
      select: { isAdmin: true }
    });

    if (!user) return false;

    if (user.isAdmin) return true;
    return server.ownerId === Number(userId);
  } catch (error) {
    return false;
  }
}


/**
 * Create backup on daemon using /container/backup endpoint
 */
async function createBackupOnDaemon(
  server: any,
  backupName: string,
  logger: Logger
): Promise<{ success: boolean; backup?: any; error?: string }> {
  try {
    logger.info(`Creating backup on daemon: ${backupName}`);

    const response = await axios({
      method: 'POST',
      url: `http://${server.node.address}:${server.node.port}/container/backup`,
      auth: { username: 'Airlink', password: server.node.key },
      headers: { 'Content-Type': 'application/json' },
      data: {
        id: server.UUID,
        name: backupName
      },
      timeout: 1800000 // 30 minutes
    });

    if (response.status === 200 && response.data.success && response.data.backup) {
      logger.info(`Backup created: ${response.data.backup.filePath}`);
      return { success: true, backup: response.data.backup };
    }

    return { success: false, error: 'Failed to create backup on daemon' };
  } catch (error: any) {
    if (error.code === 'ECONNABORTED') {
      logger.error('Backup creation timed out after 30 minutes');
      return { success: false, error: 'Backup timed out. Server may be too large.' };
    }
    logger.error(`Error creating backup on daemon:`, error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Download backup from daemon using /container/backup/download endpoint
 */
async function downloadBackupFromDaemon(
  server: any,
  backupPath: string,
  localPath: string,
  logger: Logger
): Promise<boolean> {
  try {
    logger.info(`Downloading backup from daemon: ${backupPath}`);

    const dir = path.dirname(localPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const response = await axios({
      method: 'GET',
      url: `http://${server.node.address}:${server.node.port}/container/backup/download`,
      auth: { username: 'Airlink', password: server.node.key },
      params: {
        backupPath: backupPath
      },
      responseType: 'stream',
      timeout: 900000, // 15 minutes
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    });

    if (response.status !== 200) {
      logger.error(`Failed to download backup - status ${response.status}`);
      return false;
    }

    const writer = fs.createWriteStream(localPath);
    let downloadedBytes = 0;

    response.data.on('data', (chunk: Buffer) => {
      downloadedBytes += chunk.length;
      if (downloadedBytes % (50 * 1024 * 1024) < chunk.length) {
        logger.debug(`Downloaded ${Math.round(downloadedBytes / 1024 / 1024)}MB...`);
      }
    });

    response.data.pipe(writer);

    return new Promise((resolve, reject) => {
      writer.on('finish', () => {
        logger.info(`Download complete: ${localPath} (${Math.round(downloadedBytes / 1024 / 1024)}MB)`);
        resolve(true);
      });
      writer.on('error', (err) => {
        logger.error(`Error writing backup file:`, err);
        reject(false);
      });
    });
  } catch (error: any) {
    if (error.code === 'ECONNABORTED') {
      logger.error('Download timed out');
    } else {
      logger.error(`Error downloading backup:`, error.message);
    }
    return false;
  }
}

/**
 * Delete backup from daemon using DELETE /container/backup endpoint
 */
async function deleteBackupFromDaemon(
  server: any,
  backupPath: string,
  logger: Logger
): Promise<boolean> {
  try {
    logger.info(`Deleting backup from daemon: ${backupPath}`);

    await axios({
      method: 'DELETE',
      url: `http://${server.node.address}:${server.node.port}/container/backup`,
      auth: { username: 'Airlink', password: server.node.key },
      headers: { 'Content-Type': 'application/json' },
      data: {
        backupPath: backupPath
      },
      timeout: 60000
    });

    logger.debug(`Deleted backup from daemon: ${backupPath}`);
    return true;
  } catch (error: any) {
    logger.warn(`Failed to delete backup ${backupPath}:`, error.message);
    return false;
  }
}

/**
 * Encrypt tar.gz file with password
 * Extracts, re-archives with password protection
 */
async function encryptBackup(
  inputPath: string,
  outputPath: string,
  password: string,
  logger: Logger
): Promise<boolean> {
  const tempExtractDir = path.join('/tmp', `extract_${Date.now()}`);
  
  try {
    logger.info('Encrypting backup with password...');

    // Extract the tar.gz
    fs.mkdirSync(tempExtractDir, { recursive: true });
    
    await tar.extract({
      file: inputPath,
      cwd: tempExtractDir
    });

    logger.debug('Extracted backup for encryption');

    // Re-archive with encryption
    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(password, 'salt', 32);
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(algorithm, key, iv);

    const output = fs.createWriteStream(outputPath);
    const archive = archiver('tar', {
      gzip: true,
      gzipOptions: { level: 6 }
    });

    // Write IV first
    output.write(iv);

    // Pipe archive through cipher to output
    archive.pipe(cipher).pipe(output);

    // Add all files from extracted directory
    archive.directory(tempExtractDir, false);

    await archive.finalize();

    return new Promise((resolve, reject) => {
      output.on('finish', () => {
        const authTag = cipher.getAuthTag();
        fs.appendFileSync(outputPath, authTag);
        logger.info('Backup encrypted successfully');
        resolve(true);
      });

      output.on('error', (err) => {
        logger.error('Encryption error:', err);
        reject(false);
      });

      archive.on('error', (err) => {
        logger.error('Archive error:', err);
        reject(false);
      });
    });
  } catch (error: any) {
    logger.error('Encrypt error:', error.message);
    return false;
  } finally {
    // Cleanup temp directory
    if (fs.existsSync(tempExtractDir)) {
      cleanupTempDir(tempExtractDir, logger);
    }
  }
}

/**
 * Decrypt backup
 */
async function decryptBackup(
  inputPath: string,
  outputPath: string,
  password: string,
  logger: Logger
): Promise<boolean> {
  try {
    logger.info('Decrypting backup...');

    const algorithm = 'aes-256-gcm';
    const key = crypto.scryptSync(password, 'salt', 32);
    
    const data = fs.readFileSync(inputPath);
    
    if (data.length < 32) {
      logger.error('Invalid encrypted file - too small');
      return false;
    }

    const iv = data.slice(0, 16);
    const authTag = data.slice(data.length - 16);
    const encrypted = data.slice(16, data.length - 16);
    
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    decipher.setAuthTag(authTag);
    
    const decrypted = Buffer.concat([
      decipher.update(encrypted),
      decipher.final()
    ]);
    
    fs.writeFileSync(outputPath, decrypted);
    logger.info('Backup decrypted successfully');
    return true;
  } catch (error: any) {
    logger.error('Decrypt error:', error.message);
    return false;
  }
}

/**
 * Upload to Google Drive
 */
async function uploadToDrive(
  filePath: string,
  fileName: string,
  folderId: string,
  oauth2Client: any,
  logger: Logger
): Promise<{ success: boolean; fileId?: string; error?: string }> {
  try {
    const drive = google.drive({ version: 'v3', auth: oauth2Client });
    
    const stats = fs.statSync(filePath);
    const fileSize = stats.size;
    
    logger.info(`Uploading to Drive: ${fileName} (${Math.round(fileSize / 1024 / 1024)}MB)`);
    
    const fileMetadata = {
      name: fileName,
      parents: [folderId]
    };
    
    const media = {
      mimeType: 'application/gzip',
      body: fs.createReadStream(filePath)
    };
    
    const file = await drive.files.create({
      requestBody: fileMetadata,
      media: media,
      fields: 'id, name, size'
    });
    
    logger.info(`Upload complete: ${file.data.id}`);
    return { success: true, fileId: file.data.id! };
  } catch (error: any) {
    logger.error('Upload error:', error.message);
    return { success: false, error: error.message };
  }
}

/**
 * Download from Google Drive
 */
async function downloadFromDrive(
  fileId: string,
  outputPath: string,
  oauth2Client: any,
  logger: Logger
): Promise<boolean> {
  try {
    const drive = google.drive({ version: 'v3', auth: oauth2Client });
    
    logger.info(`Downloading from Drive: ${fileId}`);
    
    const dest = fs.createWriteStream(outputPath);
    const response = await drive.files.get(
      { fileId, alt: 'media' },
      { responseType: 'stream' }
    );
    
    return new Promise((resolve, reject) => {
      response.data
        .on('end', () => {
          logger.info(`Download complete: ${fileId}`);
          resolve(true);
        })
        .on('error', (err: any) => {
          logger.error('Download error:', err);
          reject(false);
        })
        .pipe(dest);
    });
  } catch (error: any) {
    logger.error('Drive download error:', error.message);
    return false;
  }
}

/**
 * Delete from Google Drive
 */
async function deleteFromDrive(
  fileId: string,
  oauth2Client: any,
  logger: Logger
): Promise<boolean> {
  try {
    const drive = google.drive({ version: 'v3', auth: oauth2Client });
    await drive.files.delete({ fileId });
    logger.info(`Deleted from Drive: ${fileId}`);
    return true;
  } catch (error: any) {
    logger.error('Delete error:', error.message);
    return false;
  }
}

/**
 * Upload backup to daemon using /container/restore endpoint
 */
import FormData from 'form-data';

async function uploadBackupToDaemon(
  server: any,
  localPath: string,
  remotePath: string,
  logger: Logger
): Promise<boolean> {
  try {
    logger.info(`Uploading ${localPath} → ${remotePath} to daemon`);

    const form = new FormData();
    form.append('id', server.UUID);
    form.append('backupPath', remotePath);
    form.append('file', fs.createReadStream(localPath));

    const response = await axios.post(
      `http://${server.node.address}:${server.node.port}/container/restore`,
      form,
      {
        auth: { username: 'Airlink', password: server.node.key },
        headers: form.getHeaders(),
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 600000
      }
    );

    return response.status === 200 && response.data.success;
  } catch (error: any) {
    logger.error(`Error restoring backup on daemon:`, error.message);
    return false;
  }
}


/**
 * Cleanup temp file
 */
function cleanupTempFile(filePath: string | null, logger: Logger): void {
  if (filePath && fs.existsSync(filePath)) {
    try {
      fs.unlinkSync(filePath);
      logger.debug(`Cleaned up: ${filePath}`);
    } catch (error) {
      logger.warn(`Cleanup failed: ${filePath}`);
    }
  }
}

/**
 * Cleanup temp directory
 */
function cleanupTempDir(dirPath: string | null, logger: Logger): void {
  if (dirPath && fs.existsSync(dirPath)) {
    try {
      fs.rmSync(dirPath, { recursive: true, force: true });
      logger.debug(`Cleaned up directory: ${dirPath}`);
    } catch (error) {
      logger.warn(`Cleanup directory failed: ${dirPath}`);
    }
  }
}

/**
 * List backups for user
 */
export async function listBackups(
  userId: number | string,
  prisma: PrismaClient,
  logger: Logger
): Promise<ParachuteBackup[]> {
  try {
    const backups: any[] = await prisma.$queryRaw`
      SELECT * FROM Parachute_Backups
      WHERE userId = ${userId}
      ORDER BY createdAt DESC
    `;
    return backups;
  } catch (error) {
    logger.error('Error listing backups:', error);
    return [];
  }
}

/**
 * List servers accessible by user
 */
export async function listUserServers(
  userId: number | string,
  prisma: PrismaClient,
  logger: Logger
): Promise<any[]> {
  try {
    const user = await prisma.users.findUnique({
      where: { id: Number(userId) }
    });

    if (user?.isAdmin) {
      return await prisma.server.findMany({
        select: {
          UUID: true,
          name: true,
          description: true,
          Installing: true,
          Suspended: true
        },
        orderBy: { name: 'asc' }
      });
    }

    return await prisma.server.findMany({
      where: { ownerId: Number(userId) },
      select: {
        UUID: true,
        name: true,
        description: true,
        Installing: true,
        Suspended: true
      },
      orderBy: { name: 'asc' }
    });
  } catch (error) {
    logger.error('Error listing servers:', error);
    return [];
  }
}

/**
 * Create backup using daemon's backup endpoint
 */
export async function createBackup(
  userId: number | string,
  serverUUID: string,
  name: string,
  password: string | undefined,
  passwordHint: string | undefined,
  prisma: PrismaClient,
  logger: Logger
): Promise<BackupResult> {
  let downloadedBackupPath: string | null = null;
  let encryptedPath: string | null = null;
  let daemonBackupPath: string;

  try {
    logger.info(`[Backup] Starting backup for server ${serverUUID} by user ${userId}`);

    if (!serverUUID || !name) {
      return { success: false, error: 'Missing required fields' };
    }

    // Get server info with node details
    const server = await prisma.server.findUnique({
      where: { UUID: serverUUID },
      select: {
        UUID: true,
        name: true,
        Installing: true,
        Suspended: true,
        ownerId: true,
        node: {
          select: {
            address: true,
            port: true,
            key: true
          }
        }
      }
    });

    if (!server || !server.node) {
      return { success: false, error: 'Server not found or node configuration missing' };
    }

    const hasAccess = await checkServerAccess(userId, serverUUID, prisma);
    if (!hasAccess) {
      return { success: false, error: 'Access denied' };
    }

    if (server.Suspended) {
      return { success: false, error: 'Server is suspended or installing' };
    }

    const oauth2Client = await getAuthenticatedClient(userId, prisma, logger);
    if (!oauth2Client) {
      return { success: false, error: 'Not authenticated with Google Drive' };
    }

    const folderId = await getDriveFolderId(userId, prisma);
    if (!folderId) {
      return { success: false, error: 'Drive folder not found' };
    }

    // Step 1: Create backup on daemon
    logger.info('[Backup] Step 1: Creating backup on daemon...');
    sendProgress(userId, 1);
    const backupName = `parachute_${Date.now()}`;
    const backupResult = await createBackupOnDaemon(server, backupName, logger);
    
    if (!backupResult.success || !backupResult.backup) {
      return { success: false, error: backupResult.error || 'Failed to create backup on daemon' };
    }

    daemonBackupPath = backupResult.backup.filePath;
    const fileSize = backupResult.backup.size || 0;

    // Step 2: Download backup from daemon
    logger.info('[Backup] Step 2: Downloading backup from daemon...');
    sendProgress(userId, 2);
    downloadedBackupPath = path.join('/tmp', `parachute_${Date.now()}_${userId}.tar.gz`);
    const downloadSuccess = await downloadBackupFromDaemon(
      server, 
      daemonBackupPath, 
      downloadedBackupPath, 
      logger
    );
    
    if (!downloadSuccess) {
      return { success: false, error: 'Failed to download backup from daemon' };
    }

    let uploadPath = downloadedBackupPath;
    let encrypted = 0;

    // Step 3: Encrypt if password provided
    if (password) {
      logger.info('[Backup] Step 3: Encrypting backup...');
      sendProgress(userId, 3);
      encryptedPath = path.join('/tmp', `parachute_${Date.now()}_${userId}_encrypted.tar.gz`);
      const encryptSuccess = await encryptBackup(downloadedBackupPath, encryptedPath, password, logger);
      
      if (!encryptSuccess) {
        return { success: false, error: 'Failed to encrypt backup' };
      }
      
      uploadPath = encryptedPath;
      encrypted = 1;
    }

    // Step 4: Upload to Google Drive
    logger.info('[Backup] Step 4: Uploading to Google Drive...');
    sendProgress(userId, 4);
    const fileName = `${name}_${Date.now()}.tar.gz`;
    const uploadResult = await uploadToDrive(uploadPath, fileName, folderId, oauth2Client, logger);
    
    if (!uploadResult.success || !uploadResult.fileId) {
      return { success: false, error: uploadResult.error || 'Failed to upload to Drive' };
    }

    // Step 5: Clean up daemon backup
    logger.info('[Backup] Step 5: Cleaning up daemon backup...');
    sendProgress(userId, 5);
    await deleteBackupFromDaemon(server, daemonBackupPath, logger);

    // Step 6: Store in database
    logger.info('[Backup] Step 6: Saving to database...');
    sendProgress(userId, 6);
    await prisma.$executeRaw`
      INSERT INTO Parachute_Backups 
      (userId, driveFileId, backupName, serverUUID, encrypted, passwordHint, fileSize)
      VALUES (${userId}, ${uploadResult.fileId}, ${name}, ${serverUUID}, ${encrypted}, 
              ${passwordHint || null}, ${fileSize})
    `;

    const backups: any[] = await prisma.$queryRaw`
      SELECT * FROM Parachute_Backups 
      WHERE driveFileId = ${uploadResult.fileId}
    `;

    logger.info(`[Backup] Backup created successfully: ${name}`);
    
    return { success: true, data: backups[0] };
  } catch (error: any) {
    logger.error('[Backup] Error creating backup:', error);
    return { success: false, error: error.message };
  } finally {
    cleanupTempFile(downloadedBackupPath, logger);
    cleanupTempFile(encryptedPath, logger);
    clearProgress(userId);
  }
}

/**
 * Restore backup using daemon's restore endpoint
 */
export async function restoreBackup(
  userId: number | string,
  backupId: number,
  serverUUID: string,
  password: string | undefined,
  prisma: PrismaClient,
  logger: Logger
): Promise<RestoreResult> {
  let downloadPath: string | null = null;
  let decryptedPath: string | null = null;
  let uploadedBackupPath: string | null = null;

  try {
    logger.info(`[Restore] Starting restore of backup ${backupId} to server ${serverUUID}`);

    const backups: any[] = await prisma.$queryRaw`
      SELECT * FROM Parachute_Backups
      WHERE id = ${backupId} AND userId = ${userId}
    `;

    if (backups.length === 0) {
      return { success: false, error: 'Backup not found' };
    }

    const backup = backups[0];

    const server = await prisma.server.findUnique({
      where: { UUID: serverUUID },
      select: {
        UUID: true,
        name: true,
        Installing: true,
        Suspended: true,
        ownerId: true,
        node: {
          select: {
            address: true,
            port: true,
            key: true
          }
        }
      }
    });

    if (!server || !server.node) {
      return { success: false, error: 'Server not found or node configuration missing' };
    }

    const hasAccess = await checkServerAccess(userId, serverUUID, prisma);
    if (!hasAccess) {
      return { success: false, error: 'Access denied' };
    }

    const oauth2Client = await getAuthenticatedClient(userId, prisma, logger);
    if (!oauth2Client) {
      return { success: false, error: 'Not authenticated with Google Drive' };
    }

    // Step 1: Download from Drive
    logger.info('[Restore] Step 1: Downloading backup from Drive...');
    sendProgress(userId, 7);
    downloadPath = path.join('/tmp', `restore_${Date.now()}_${userId}.tar.gz`);
    const downloadSuccess = await downloadFromDrive(backup.driveFileId, downloadPath, oauth2Client, logger);
    
    if (!downloadSuccess) {
      return { success: false, error: 'Failed to download backup from Drive' };
    }

    let restorePath = downloadPath;

    // Step 2: Decrypt if encrypted
    if (backup.encrypted === 1) {
      if (!password) {
        return { success: false, error: 'Password required for encrypted backup' };
      }

      logger.info('[Restore] Step 2: Decrypting backup...');
      sendProgress(userId, 8);
      decryptedPath = path.join('/tmp', `restore_${Date.now()}_${userId}_decrypted.tar.gz`);
      const decryptSuccess = await decryptBackup(downloadPath, decryptedPath, password, logger);
      
      if (!decryptSuccess) {
        return { success: false, error: 'Failed to decrypt backup - incorrect password?' };
      }
      
      restorePath = decryptedPath;
    }

    // Step 3: Upload to daemon and restore
    logger.info('[Restore] Step 3: Restoring backup on daemon...');
    sendProgress(userId, 9);
    // First, we need to copy the backup to the daemon's backups directory
    // We'll use the daemon's backup path format
    uploadedBackupPath = `backups/${server.UUID}/restore_${Date.now()}.tar.gz`;
    
    // Note: This requires uploading the file to the daemon first
    // For now, we'll use the restore endpoint directly with the local file
    // This assumes the daemon can access a shared filesystem or we need to implement file upload
    
    const restoreSuccess = await uploadBackupToDaemon(server, restorePath, uploadedBackupPath, logger);
    
    if (!restoreSuccess) {
      return { success: false, error: 'Failed to restore backup on daemon' };
    }

    logger.info(`[Restore] Backup restored successfully: ${backup.backupName}`);
    
    return { success: true };
  } catch (error: any) {
    logger.error('[Restore] Error restoring backup:', error);
    return { success: false, error: error.message };
  } finally {
    cleanupTempFile(downloadPath, logger);
    cleanupTempFile(decryptedPath, logger);
    clearProgress(userId);
  }
}

/**
 * Delete backup
 */
export async function deleteBackup(
  userId: number | string,
  backupId: number,
  prisma: PrismaClient,
  logger: Logger
): Promise<{ success: boolean; error?: string }> {
  try {
    const backups: any[] = await prisma.$queryRaw`
      SELECT * FROM Parachute_Backups
      WHERE id = ${backupId} AND userId = ${userId}
    `;

    if (backups.length === 0) {
      return { success: false, error: 'Backup not found' };
    }

    const backup = backups[0];

    const oauth2Client = await getAuthenticatedClient(userId, prisma, logger);
    if (!oauth2Client) {
      return { success: false, error: 'Not authenticated with Google Drive' };
    }

    const deleteSuccess = await deleteFromDrive(backup.driveFileId, oauth2Client, logger);
    
    if (!deleteSuccess) {
      logger.warn(`Failed to delete from Drive, removing from DB anyway: ${backup.driveFileId}`);
    }

    await prisma.$executeRaw`
      DELETE FROM Parachute_Backups WHERE id = ${backupId}
    `;

    logger.info(`Backup deleted: ${backup.backupName}`);
    
    return { success: true };
  } catch (error: any) {
    logger.error('Error deleting backup:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Rename backup
 */
export async function renameBackup(
  userId: number | string,
  backupId: number,
  newName: string,
  prisma: PrismaClient,
  logger: Logger
): Promise<{ success: boolean; error?: string }> {
  try {
    const backups: any[] = await prisma.$queryRaw`
      SELECT * FROM Parachute_Backups
      WHERE id = ${backupId} AND userId = ${userId}
    `;

    if (backups.length === 0) {
      return { success: false, error: 'Backup not found' };
    }

    await prisma.$executeRaw`
      UPDATE Parachute_Backups
      SET backupName = ${newName}
      WHERE id = ${backupId}
    `;

    logger.info(`Backup renamed: ${backups[0].backupName} -> ${newName}`);
    
    return { success: true };
  } catch (error: any) {
    logger.error('Error renaming backup:', error);
    return { success: false, error: error.message };
  }
}