/**
 * =============================================================================
 * File: oauth.ts
 * Project: Parachute
 * Author: g-flame
 * =============================================================================
 *
 * CREDITS:
 * - Parachute addon developed by g-flame
 * - Panel by AirlinkLabs
 *
 * NOTES:
 * - This file is part of the Parachute – Airlink Addons project
 * - All TypeScript logic written by g-flame
 *
 * =============================================================================
 */


import { Request, Response } from 'express';
import { google } from 'googleapis';
import crypto from 'crypto';
import { PrismaClient, Logger, DriveTokens, AuthStatus, OAuth2Client } from '../types';
import { GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, APP_URL, PARACHUTE_COOKIE_SECRET } from './config';

const SCOPES = [
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/drive.file'
];

/**
 * Get OAuth2 client instance
 */
function getOAuth2Client(): OAuth2Client {
  const redirectUri = `${APP_URL}/parachute/oauth/google/callback`;

  if (!GOOGLE_CLIENT_ID || !GOOGLE_CLIENT_SECRET || !APP_URL) {
    throw new Error('Missing OAuth2 configuration in environment variables');
  }

  return new google.auth.OAuth2(GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, redirectUri);
}

/**
 * Encrypt tokens for storage
 */
function encryptTokens(tokens: DriveTokens): string {
  const algorithm = 'aes-256-gcm';
  const key = crypto.scryptSync(PARACHUTE_COOKIE_SECRET, 'salt', 32);
  const iv = crypto.randomBytes(16);
  
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  let encrypted = cipher.update(JSON.stringify(tokens), 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  return JSON.stringify({
    iv: iv.toString('hex'),
    encrypted,
    authTag: authTag.toString('hex')
  });
}

/**
 * Decrypt stored tokens
 */
function decryptTokens(tokenRef: string): DriveTokens {
  const algorithm = 'aes-256-gcm';
  const key = crypto.scryptSync(PARACHUTE_COOKIE_SECRET, 'salt', 32);
  
  const data = JSON.parse(tokenRef);
  const iv = Buffer.from(data.iv, 'hex');
  const authTag = Buffer.from(data.authTag, 'hex');
  
  const decipher = crypto.createDecipheriv(algorithm, key, iv);
  decipher.setAuthTag(authTag);
  
  let decrypted = decipher.update(data.encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return JSON.parse(decrypted);
}

/**
 * Create signed state token with userId
 */
function createStateToken(userId: number | string): string {
  const payload = JSON.stringify({
    userId,
    timestamp: Date.now()
  });
  
  const hmac = crypto.createHmac('sha256', PARACHUTE_COOKIE_SECRET);
  hmac.update(payload);
  const signature = hmac.digest('hex');
  
  const state = Buffer.from(JSON.stringify({
    payload,
    signature
  })).toString('base64');
  
  return state;
}

/**
 * Verify and extract userId from state token
 */
function verifyStateToken(state: string): number | null {
  try {
    const decoded = JSON.parse(Buffer.from(state, 'base64').toString('utf8'));
    const { payload, signature } = decoded;
    
    // Verify signature
    const hmac = crypto.createHmac('sha256', PARACHUTE_COOKIE_SECRET);
    hmac.update(payload);
    const expectedSignature = hmac.digest('hex');
    
    if (signature !== expectedSignature) {
      return null;
    }
    
    const data = JSON.parse(payload);
    
    // Check if token is not too old (15 minutes max)
    if (Date.now() - data.timestamp > 15 * 60 * 1000) {
      return null;
    }
    
    return Number(data.userId);
  } catch (error) {
    return null;
  }
}

/**
 * Start OAuth flow with state parameter
 */
export function handleOAuthConnect(req: Request, res: Response, logger: Logger): void {
  try {
    if (!req.session?.user) {
      res.redirect('/login?redirect=/parachute');
      return;
    }

    const oauth2Client = getOAuth2Client();
    
    // Create state token with userId
    const state = createStateToken(req.session.user.id);
    
    const authUrl = oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: SCOPES,
      prompt: 'consent',
      state: state
    });

    logger.info(`Initiating OAuth flow for user ${req.session.user.id}`);
    res.redirect(authUrl);
  } catch (error) {
    logger.error('Error initiating OAuth:', error);
    res.redirect('/parachute?error=oauth_init_failed');
  }
}

/**
 * Handle OAuth callback - stateless, recovers userId from state
 */
export async function handleOAuthCallback(
  req: Request,
  res: Response,
  prisma: PrismaClient,
  logger: Logger
): Promise<void> {
  try {
    const code = req.query.code as string;
    const state = req.query.state as string;

    if (!code) {
      logger.error('No authorization code received');
      res.redirect('/parachute?error=no_code');
      return;
    }

    if (!state) {
      logger.error('No state parameter received');
      res.redirect('/parachute?error=invalid_state');
      return;
    }

    // Verify and extract userId from state
    const userId = verifyStateToken(state);
    if (!userId) {
      logger.error('Invalid or expired state token');
      res.redirect('/parachute?error=invalid_state');
      return;
    }

    logger.info(`Processing OAuth callback for user ${userId}`);

    const oauth2Client = getOAuth2Client();
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    // Fetch user profile
    const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
    const userInfo = await oauth2.userinfo.get();

    const displayName = userInfo.data.name || '';
    const email = userInfo.data.email || '';
    const pictureUrl = userInfo.data.picture || '';

    // Create or get Drive folder
    const drive = google.drive({ version: 'v3', auth: oauth2Client });
    const folderName = `parachute_chute_${userId}`;
    
    let folderId: string;
    const folderSearch = await drive.files.list({
      q: `name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
      fields: 'files(id, name)',
      spaces: 'drive'
    });

    if (folderSearch.data.files && folderSearch.data.files.length > 0) {
      folderId = folderSearch.data.files[0].id!;
      logger.info(`Using existing Drive folder: ${folderId}`);
    } else {
      const folderMetadata = {
        name: folderName,
        mimeType: 'application/vnd.google-apps.folder'
      };
      const folder = await drive.files.create({
        requestBody: folderMetadata,
        fields: 'id'
      });
      folderId = folder.data.id!;
      logger.info(`Created new Drive folder: ${folderId}`);
    }

    // Encrypt and store tokens
    const tokenRef = encryptTokens(tokens as DriveTokens);

    // Store in database
    await prisma.$executeRaw`
      INSERT INTO Parachute_Auth (userId, driveFolderId, tokenRef, displayName, email, pictureUrl)
      VALUES (${userId}, ${folderId}, ${tokenRef}, ${displayName}, ${email}, ${pictureUrl})
      ON CONFLICT(userId) DO UPDATE SET
        driveFolderId = ${folderId},
        tokenRef = ${tokenRef},
        displayName = ${displayName},
        email = ${email},
        pictureUrl = ${pictureUrl}
    `;

    // Always restore/ensure session is set
    const user = await prisma.users.findUnique({
      where: { id: Number(userId) }
    });

    if (!user) {
      logger.error(`User ${userId} not found in database`);
      res.redirect('/parachute?error=user_not_found');
      return;
    }

    // Set or restore session
    req.session.user = {
      id: user.id,
      username: user.username,
      email: user.email || undefined,
      isAdmin: user.isAdmin
    };

    // Save session explicitly before redirect
    req.session.save((err) => {
      if (err) {
        logger.error('Error saving session:', err);
        res.redirect('/parachute?error=session_failed');
        return;
      }
      
      logger.info(`OAuth completed for user ${userId}`);
      res.redirect('/parachute?success=connected');
    });
  } catch (error) {
    logger.error('OAuth callback error:', error);
    res.redirect('/parachute?error=oauth_failed');
  }
}

/**
 * Get authentication status for user
 */
export async function getAuthStatus(
  userId: number | string,
  prisma: PrismaClient,
  logger: Logger
): Promise<AuthStatus> {
  try {
    const auth: any[] = await prisma.$queryRaw`
      SELECT displayName, email, pictureUrl, driveFolderId
      FROM Parachute_Auth
      WHERE userId = ${userId}
    `;

    if (auth.length === 0) {
      return { connected: false };
    }

    const folderName = `parachute_chute_${userId}`;
    
    return {
      connected: true,
      email: auth[0].email,
      displayName: auth[0].displayName,
      pictureUrl: auth[0].pictureUrl,
      folderName
    };
  } catch (error) {
    logger.error('Error fetching auth status:', error);
    return { connected: false };
  }
}

/**
 * Disconnect Google Drive
 */
export async function disconnectGoogle(
  userId: number | string,
  prisma: PrismaClient,
  logger: Logger
): Promise<void> {
  try {
    await prisma.$executeRaw`
      DELETE FROM Parachute_Auth WHERE userId = ${userId}
    `;
    logger.info(`User ${userId} disconnected from Google Drive`);
  } catch (error) {
    logger.error('Error disconnecting:', error);
    throw error;
  }
}

/**
 * Get OAuth client with stored credentials
 */
export async function getAuthenticatedClient(
  userId: number | string,
  prisma: PrismaClient,
  logger: Logger
): Promise<OAuth2Client | null> {
  try {
    const auth: any[] = await prisma.$queryRaw`
      SELECT tokenRef FROM Parachute_Auth WHERE userId = ${userId}
    `;

    if (auth.length === 0) {
      return null;
    }

    const tokens = decryptTokens(auth[0].tokenRef);
    const oauth2Client = getOAuth2Client();
    oauth2Client.setCredentials(tokens);

    return oauth2Client;
  } catch (error) {
    logger.error('Error getting authenticated client:', error);
    return null;
  }
}

/**
 * Get Drive folder ID for user
 */
export async function getDriveFolderId(
  userId: number | string,
  prisma: PrismaClient
): Promise<string | null> {
  try {
    const result: any[] = await prisma.$queryRaw`
      SELECT driveFolderId FROM Parachute_Auth WHERE userId = ${userId}
    `;
    return result.length > 0 ? result[0].driveFolderId : null;
  } catch (error) {
    return null;
  }
}