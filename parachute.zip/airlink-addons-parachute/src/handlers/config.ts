/**
 * =============================================================================
 * File: config.ts
 * Project: Parachute
 * Author: g-flame
 * =============================================================================
 *
 * CREDITS:
 * - Parachute addon developed by g-flame
 * - Panel by AirlinkLabs
 *
 * NOTES:
 * - This file is part of the Parachute – Airlink Addons project
 * - All TypeScript logic written by g-flame
 *
 * =============================================================================
 */


import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';

// Load .env from project root (two levels up from dist or src)
const projectRoot = path.resolve(__dirname, '../..');
const envPath = path.join(projectRoot, '.env');

if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
} else {
  console.warn(`[Parachute] .env file not found at ${envPath}`);
}

// Export configuration constants
export const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID?.trim() || '';
export const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET?.trim() || '';
export const APP_URL = process.env.APP_URL?.trim() || 'http://localhost:3000';
export const PARACHUTE_COOKIE_SECRET = process.env.PARACHUTE_COOKIE_SECRET || 'default_secret_change_me';

// Validate required config
export function validateConfig(): { valid: boolean; missing: string[] } {
  const missing: string[] = [];
  
  if (!GOOGLE_CLIENT_ID) missing.push('GOOGLE_CLIENT_ID');
  if (!GOOGLE_CLIENT_SECRET) missing.push('GOOGLE_CLIENT_SECRET');
  if (!APP_URL) missing.push('APP_URL');
  
  return {
    valid: missing.length === 0,
    missing
  };
}