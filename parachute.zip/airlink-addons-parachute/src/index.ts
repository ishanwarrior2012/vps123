/**
 * =============================================================================
 * File: index.ts
 * Project: Parachute
 * Author: g-flame
 * =============================================================================
 *
 * CREDITS:
 * - Parachute addon developed by g-flame
 * - Panel by AirlinkLabs
 *
 * NOTES:
 * - This file is part of the Parachute – Airlink Addons project
 * - All TypeScript logic written by g-flame
 *
 * =============================================================================
 */


import { Router, Request, Response } from 'express';
import path from 'path';
import { AddonAPI, getProgress } from './types';
import { setupUI } from './ui';
import {
  handleOAuthConnect,
  handleOAuthCallback,
  getAuthStatus,
  disconnectGoogle
} from './handlers/oauth';
import {
  listBackups,
  createBackup,
  restoreBackup,
  deleteBackup,
  renameBackup,
  listUserServers
} from './handlers/files';
import { validateConfig } from './handlers/config';

export default async function(router: Router, api: AddonAPI): Promise<void> {
  const { logger, prisma, viewsPath, getComponentPath } = api;

  logger.info('Parachute addon initializing...');

  // Validate configuration
  const configValidation = validateConfig();
  if (!configValidation.valid) {
    logger.error(`Missing required environment variables: ${configValidation.missing.join(', ')}`);
    logger.error('Please configure these variables in your .env file');
  }

  // Setup UI components
  setupUI(api);

  // Main page route
  router.get('/', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.redirect('/login?redirect=/parachute');
        return;
      }

      const status = await getAuthStatus(req.session.user.id, prisma, logger);
      const settings = await prisma.settings.findUnique({ where: { id: 1 } });

      res.render(path.join(viewsPath, 'parachute.ejs'), {
        title: 'Parachute - Backup Manager',
        user: req.session.user,
        req,
        settings,
        status,
        components: {
          header: getComponentPath('views/components/header'),
          template: getComponentPath('views/components/template'),
          footer: getComponentPath('views/components/footer'),
          google: path.join(viewsPath, 'google.ejs'),
          fileList: path.join(viewsPath, 'file.ejs'),
          serverSelector: path.join(viewsPath, 'server-selector.ejs'),
          createBackupModal: path.join(viewsPath, 'create-backup-modal.ejs'),
          restoreBackupModal: path.join(viewsPath, 'restore-backup-modal.ejs'),
          renameBackupModal: path.join(viewsPath, 'rename-backup-modal.ejs'),
          deleteConfirmModal: path.join(viewsPath, 'delete-confirm-modal.ejs'),
          toast: path.join(viewsPath, 'toast.ejs')
        }
      });
    } catch (error) {
      logger.error('Error rendering parachute page:', error);
      res.status(500).send('Failed to load backup manager');
    }
  });

  // OAuth routes
  router.get('/oauth/google/connect', (req: Request, res: Response) => {
    if (!req.session?.user) {
      res.redirect('/login?redirect=/parachute');
      return;
    }
    handleOAuthConnect(req, res, logger);
  });

  router.get('/oauth/google/callback', async (req: Request, res: Response) => {
    await handleOAuthCallback(req, res, prisma, logger);
  });

  // API routes
  router.get('/api/status', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const status = await getAuthStatus(req.session.user.id, prisma, logger);
      res.json({ success: true, data: status });
    } catch (error) {
      logger.error('Error fetching auth status:', error);
      res.status(500).json({ success: false, error: 'Failed to fetch status' });
    }
  });

  router.post('/api/disconnect', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      await disconnectGoogle(req.session.user.id, prisma, logger);
      res.json({ success: true, message: 'Disconnected from Google Drive' });
    } catch (error) {
      logger.error('Error disconnecting:', error);
      res.status(500).json({ success: false, error: 'Failed to disconnect' });
    }
  });

  router.get('/api/backups', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const backups = await listBackups(req.session.user.id, prisma, logger);
      res.json({ success: true, data: backups });
    } catch (error) {
      logger.error('Error listing backups:', error);
      res.status(500).json({ success: false, error: 'Failed to list backups' });
    }
  });

  router.get('/api/servers', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const servers = await listUserServers(req.session.user.id, prisma, logger);
      res.json({ success: true, data: servers });
    } catch (error) {
      logger.error('Error listing servers:', error);
      res.status(500).json({ success: false, error: 'Failed to list servers' });
    }
  });

  router.post('/api/backup/create', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const { serverUUID, name, password, passwordHint } = req.body;

      if (!serverUUID || !name) {
        res.status(400).json({ success: false, error: 'Missing required fields' });
        return;
      }

      if (name.length > 100) {
        res.status(400).json({ success: false, error: 'Backup name too long (max 100 characters)' });
        return;
      }

      if (passwordHint && passwordHint.length > 200) {
        res.status(400).json({ success: false, error: 'Password hint too long (max 200 characters)' });
        return;
      }

      const result = await createBackup(
        req.session.user.id,
        serverUUID,
        name,
        password,
        passwordHint,
        prisma,
        logger
      );

      if (result.success) {
        res.json({ success: true, data: result.data, message: 'Backup created successfully' });
      } else {
        res.status(500).json({ success: false, error: result.error });
      }
    } catch (error) {
      logger.error('Error creating backup:', error);
      res.status(500).json({ success: false, error: 'Failed to create backup' });
    }
  });

  router.post('/api/backup/:id/restore', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const backupId = parseInt(req.params.id, 10);
      const { serverUUID, password } = req.body;

      if (isNaN(backupId)) {
        res.status(400).json({ success: false, error: 'Invalid backup ID' });
        return;
      }

      if (!serverUUID) {
        res.status(400).json({ success: false, error: 'Server UUID required' });
        return;
      }

      const result = await restoreBackup(
        req.session.user.id,
        backupId,
        serverUUID,
        password,
        prisma,
        logger
      );

      if (result.success) {
        res.json({ success: true, message: 'Backup restored successfully' });
      } else {
        res.status(500).json({ success: false, error: result.error });
      }
    } catch (error) {
      logger.error('Error restoring backup:', error);
      res.status(500).json({ success: false, error: 'Failed to restore backup' });
    }
  });

router.get('/api/progress', (req: Request, res: Response): void => {
  if (!req.session?.user) {
    res.status(401).json({ success: false, error: 'Not authenticated' });
    return;
  }

  const userId = req.session.user.id.toString();
  const step = getProgress(userId); 

  res.json({ success: true, step });
});


  router.post('/api/backup/:id/delete', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const backupId = parseInt(req.params.id, 10);

      if (isNaN(backupId)) {
        res.status(400).json({ success: false, error: 'Invalid backup ID' });
        return;
      }

      const result = await deleteBackup(req.session.user.id, backupId, prisma, logger);

      if (result.success) {
        res.json({ success: true, message: 'Backup deleted successfully' });
      } else {
        res.status(500).json({ success: false, error: result.error });
      }
    } catch (error) {
      logger.error('Error deleting backup:', error);
      res.status(500).json({ success: false, error: 'Failed to delete backup' });
    }
  });

  router.post('/api/backup/:id/rename', async (req: Request, res: Response): Promise<void> => {
    try {
      if (!req.session?.user) {
        res.status(401).json({ success: false, error: 'Not authenticated' });
        return;
      }

      const backupId = parseInt(req.params.id, 10);
      const { name } = req.body;

      if (isNaN(backupId)) {
        res.status(400).json({ success: false, error: 'Invalid backup ID' });
        return;
      }

      if (!name) {
        res.status(400).json({ success: false, error: 'Name required' });
        return;
      }

      if (name.length > 100) {
        res.status(400).json({ success: false, error: 'Name too long (max 100 characters)' });
        return;
      }

      const result = await renameBackup(req.session.user.id, backupId, name, prisma, logger);

      if (result.success) {
        res.json({ success: true, message: 'Backup renamed successfully' });
      } else {
        res.status(500).json({ success: false, error: result.error });
      }
    } catch (error) {
      logger.error('Error renaming backup:', error);
      res.status(500).json({ success: false, error: 'Failed to rename backup' });
    }
  });

  logger.info('Parachute addon initialized successfully');
}