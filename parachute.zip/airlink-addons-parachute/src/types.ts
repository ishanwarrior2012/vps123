/**
 * =============================================================================
 * File: types.ts
 * Project: Parachute
 * Author: g-flame
 * =============================================================================
 *
 * CREDITS:
 * - Parachute addon developed by g-flame
 * - Panel by AirlinkLabs
 *
 * NOTES:
 * - This file is part of the Parachute – Airlink Addons project
 * - All TypeScript logic written by g-flame
 *
 * =============================================================================
 */


import { Router } from 'express';
import "express-session";
import type { PrismaClient as _PrismaClient } from "@prisma/client";
import { google } from 'googleapis';

export type PrismaClient = _PrismaClient;
export type OAuth2Client = InstanceType<typeof google.auth.OAuth2>;

declare module 'express-session' {
  interface SessionData {
    user?: {
      id: number | string;
      username?: string;
      email?: string;
      isAdmin?: boolean;
    };
  }
}

export interface AddonAPI {
  registerRoute: (path: string, router: Router) => void;
  logger: Logger;
  prisma: PrismaClient;
  addonPath: string;
  viewsPath: string;
  getComponentPath: (componentPath: string) => string;
  renderView: (viewName: string, data?: any) => string;
  utils: {
    isUserAdmin: (userId: number | string) => Promise<boolean>;
    checkServerAccess: (userId: number | string, serverId: number | string) => Promise<boolean>;
    getServerById: (serverId: number | string) => Promise<Server | null>;
    getServerByUUID: (uuid: string) => Promise<Server | null>;
    getServerPorts: (server: Server) => Port[];
    getPrimaryPort: (server: Server) => Port | null;
  };
  ui?: UIManager;
}

export interface Logger {
  info: (message: string, ...args: any[]) => void;
  warn: (message: string, ...args: any[]) => void;
  error: (message: string, ...args: any[]) => void;
  debug: (message: string, ...args: any[]) => void;
}

export interface UIManager {
  addSidebarItem?: (item: SidebarItem) => void;
  removeSidebarItem?: (id: string) => void;
  getSidebarItems?: (section?: string) => SidebarItem[];
  addServerMenuItem?: (item: ServerMenuItem) => void;
  removeServerMenuItem?: (id: string) => void;
  getServerMenuItems?: (feature?: string) => ServerMenuItem[];
  addServerSection?: (section: ServerSection) => void;
  removeServerSection?: (id: string) => void;
  getServerSections?: () => ServerSection[];
  addServerSectionItem?: (sectionId: string, item: ServerSectionItem) => void;
  removeServerSectionItem?: (sectionId: string, itemId: string) => void;
  getServerSectionItems?: (sectionId: string) => ServerSectionItem[];
}

export interface SidebarItem {
  id: string;
  label: string;
  icon?: string;
  url: string;
  section?: 'main' | 'system' | 'other';
  order?: number;
  isAdminItem?: boolean;
}

export interface ServerMenuItem {
  id: string;
  label: string;
  icon?: string;
  url: string;
  feature?: 'management' | 'settings' | 'advanced' | string;
  order?: number;
}

export interface ServerSection {
  id: string;
  label?: string;
  title?: string;
  icon?: string;
  order?: number;
  items?: ServerSectionItem[];
}

export interface ServerSectionItem {
  id: string;
  label: string;
  url?: string;
  value?: string;
  type?: 'link' | 'button' | 'text' | string;
  onClick?: string;
  order?: number;
}

export interface Server {
  UUID: string;
  name?: string;
  description?: string;
  status?: string;
  ownerId?: number | string;
  nodeId?: number;
  imageId?: number;
  Installing?: boolean;
  Suspended?: boolean;
  node?: Node;
  image?: Image;
  owner?: User;
  Ports?: string;
  Memory?: number;
  Cpu?: number;
  Storage?: number;
}

export interface Node {
  id: number;
  name?: string;
  address?: string;
  port?: number;
  key?: string;
}

export interface Image {
  id: number;
  name?: string;
  info?: string;
}

export interface User {
  id: number | string;
  username?: string;
  email?: string;
  isAdmin?: boolean;
}

export interface Port {
  port: number;
  protocol?: string;
  primary?: boolean;
}

export interface Settings {
  id: number;
  title?: string;
  logo?: string;
  theme?: string;
}

// Parachute-specific types

export interface ParachuteAuth {
  id: number;
  userId: number;
  driveFolderId: string;
  tokenRef: string;
  displayName: string | null;
  email: string | null;
  pictureUrl: string | null;
  createdAt: Date;
}

export interface ParachuteBackup {
  id: number;
  userId: number;
  driveFileId: string;
  backupName: string;
  serverUUID: string;
  encrypted: number;
  passwordHint: string | null;
  fileSize: number | null;
  createdAt: Date;
}

export interface AuthStatus {
  connected: boolean;
  email?: string;
  displayName?: string;
  pictureUrl?: string;
  folderName?: string;
}

export interface BackupResult {
  success: boolean;
  data?: ParachuteBackup;
  error?: string;
}

export interface RestoreResult {
  success: boolean;
  error?: string;
}

export interface DriveTokens {
  access_token: string;
  refresh_token?: string;
  expiry_date?: number;
  token_type?: string;
  scope?: string;
}
// utils/progress.ts
const progressMap = new Map<string, number>();

export function sendProgress(userId: string | number, step: number) {
  progressMap.set(userId.toString(), step);
}

export function getProgress(userId: string | number): number {
  return progressMap.get(userId.toString()) || 0;
}

export function clearProgress(userId: string | number) {
  progressMap.delete(userId.toString());
}
